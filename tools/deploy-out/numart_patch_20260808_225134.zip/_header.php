<?php
// Suppress direct display of PHP warnings/notices so they don't break JSON/HTML output in pages.
// Errors should still be logged; display is disabled for UI stability.
ini_set('display_errors', '0');
error_reporting(E_ALL);

include '_header-artibut.php';
?>
<?php
$levelLogin = $_SESSION['user_level'];
$status = $_SESSION['user_status'];
$base_url = "https://api.numartmagelang.com";
if ($status === '0') {
  echo "
          <script>
            alert('Akun Tidak Aktif');
            window.location='./';
          </script>";
}
?>
<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>POS - NUMART</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Font Awesome -->
  <!-- Favicon -->
  <link rel="icon" type="img/png" sizes="32x32" href="https://pos.numartmagelang.com/dist/img/logobumnupacnu.png">
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <link rel="stylesheet" type="text/css" href="dist/css/font-awesome.min.css">
  <!-- Ionicons -->
  <!-- <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css"> -->
  <!-- Tempusdominus Bbootstrap 4 -->
  <link rel="stylesheet" href="plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- JQVMap -->
  <link rel="stylesheet" href="plugins/jqvmap/jqvmap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
  <!-- Daterange picker -->
  <link rel="stylesheet" href="plugins/daterangepicker/daterangepicker.css">
  <!-- summernote -->
  <link rel="stylesheet" href="plugins/summernote/summernote-bs4.css">
  <!-- Google Font: Source Sans Pro -->
  <!-- <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet"> -->
  <!-- Select2 -->
  <link rel="stylesheet" href="plugins/select2/css/select2.min.css">
  <link rel="stylesheet" href="plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css">
  <!-- Sweetalert -->
  <link rel="stylesheet" type="text/css" href="dist/node_modules/sweetalert2/dist/sweetalert2.css">
  <link rel="stylesheet" type="text/css" href="dist/css/loaders.css">

  <link rel="stylesheet" type="text/css" href="dist/css/style.css">

  <!-- Export Excel -->
  <link rel="stylesheet" type="text/css" href="dist/css/tableexport.min.css">
  <style>
    caption.tableexport-caption {
      caption-side: top !important;
    }

    .button-default.xlsx {
      display: none !important;
    }
  </style>


  <!-- jQuery -->
  <script src="plugins/jquery/jquery.min.js"></script>
  <!-- jQuery UI 1.11.4 -->
  <script src="plugins/jquery-ui/jquery-ui.min.js"></script>
  <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
  <script>
    $.widget.bridge('uibutton', $.ui.button)
  </script>
  <!-- Bootstrap 4 -->
  <script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Sweetalert -->
  <script src="dist/node_modules/sweetalert2/dist/sweetalert2.all.min.js"></script>

  <!-- HTML5 QR Code Scanner -->
  <script src="https://unpkg.com/html5-qrcode"></script>

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <style>
    @import url("https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css");
  </style>
</head>

<body class="hold-transition sidebar-mini layout-fixed<?= !empty($posAutoHideSidebar) ? ' sidebar-collapse' : ''; ?><?= !empty($posBodyExtraClass) ? ' ' . htmlspecialchars((string) $posBodyExtraClass, ENT_QUOTES, 'UTF-8') : ''; ?>">
<?php if (!empty($posBodyExtraClass)) : ?>
<script>try{if(localStorage.getItem('numart_pos_dark_mode')==='1')document.body.classList.add('bl-dark-mode');}catch(e){}</script>
<?php endif; ?>
  <div class="wrapper">